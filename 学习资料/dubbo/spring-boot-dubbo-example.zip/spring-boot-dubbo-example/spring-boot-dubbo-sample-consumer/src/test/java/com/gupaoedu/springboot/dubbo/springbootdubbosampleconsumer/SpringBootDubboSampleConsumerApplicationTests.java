package com.gupaoedu.springboot.dubbo.springbootdubbosampleconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDubboSampleConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
