package com.gupaoedu.springboot.dubbo.springbootdubbosampleprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDubboSampleProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
