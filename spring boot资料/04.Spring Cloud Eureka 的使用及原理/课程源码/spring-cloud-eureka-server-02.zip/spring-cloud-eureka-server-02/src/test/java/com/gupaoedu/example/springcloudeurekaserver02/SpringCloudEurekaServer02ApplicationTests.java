package com.gupaoedu.example.springcloudeurekaserver02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudEurekaServer02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
