package com.gupaoedu.springcloud.example.springclouduserservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudUserServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
