package com.gupaoedu.demo02;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * 咕泡学院，只为更好的你
 * 咕泡学院-Mic: 2227324689
 * http://www.gupaoedu.com
 **/
@Service
public class Demo02Service {

}
