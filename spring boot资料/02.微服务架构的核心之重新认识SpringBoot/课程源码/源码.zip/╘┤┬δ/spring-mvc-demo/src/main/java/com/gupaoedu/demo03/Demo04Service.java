package com.gupaoedu.demo03;

/**
 * 咕泡学院，只为更好的你
 * 咕泡学院-Mic: 2227324689
 * http://www.gupaoedu.com
 **/
public class Demo04Service {
    private Demo03Service demo03Service;

    public Demo03Service getDemo03Service() {
        return demo03Service;
    }

    public void setDemo03Service(Demo03Service demo03Service) {
        this.demo03Service = demo03Service;
    }
}
