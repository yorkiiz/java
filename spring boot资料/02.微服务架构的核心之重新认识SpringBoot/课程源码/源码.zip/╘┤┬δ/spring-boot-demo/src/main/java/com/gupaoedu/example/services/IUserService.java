package com.gupaoedu.example.services;

import com.gupaoedu.example.dao.entity.User;

/**
 * 咕泡学院，只为更好的你
 * 咕泡学院-Mic: 2227324689
 * http://www.gupaoedu.com
 **/
public interface IUserService {
    int insert(User user);


}
